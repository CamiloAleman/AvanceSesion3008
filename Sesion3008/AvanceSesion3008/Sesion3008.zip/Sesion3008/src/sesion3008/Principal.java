/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sesion3008;

import modelos.Persona;
import modelos.SEXO;

/**
 *
 * @author labc205
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Persona maria = new Persona (1, "Maria", "Lopez", "", SEXO.Mujer);
    }
    
}
